import torch
import librosa
import os
from pydub import AudioSegment

class SpeechToTextEngine:
    def __init__(self, model_loader, transliterator):
        self.model = model_loader.get_model()
        self.processor = model_loader.get_processor()
        self.transliterator = transliterator
        self.sampling_rate = model_loader.get_sampling_rate()

    def convert_to_wav(self, file_path):
        """Convert any audio file to 16kHz mono WAV."""
        try:
            if file_path.lower().endswith(".wav"):
                return file_path  # Already WAV
            audio = AudioSegment.from_file(file_path)
            audio = audio.set_channels(1).set_frame_rate(self.sampling_rate)
            wav_path = "converted_temp.wav"
            audio.export(wav_path, format="wav")
            return wav_path
        except Exception as e:
            print("Error converting file to WAV:", str(e))
            return None

    def transcribe(self, audio_path, output_format="both"):
        audio_path = self.convert_to_wav(audio_path)
        if audio_path is None or not os.path.exists(audio_path):
            print("Error: Audio file not found or could not convert to WAV.")
            return None

        try:
            speech, _ = librosa.load(audio_path, sr=self.sampling_rate)
        except Exception as e:
            print("Error loading audio file:", str(e))
            return None

        try:
            inputs = self.processor(
                speech,
                sampling_rate=self.sampling_rate,
                return_tensors="pt",
                padding=True
            )
            with torch.no_grad():
                logits = self.model(inputs.input_values).logits
            predicted_ids = torch.argmax(logits, dim=-1)
            urdu_text = self.processor.batch_decode(predicted_ids)[0]

            if output_format == "urdu":
                return urdu_text
            if output_format == "roman":
                return self.transliterator.convert(urdu_text)
            if output_format == "both":
                return {"urdu": urdu_text, "roman": self.transliterator.convert(urdu_text)}
        except Exception as e:
            print("Error transcribing audio:", str(e))
            return None