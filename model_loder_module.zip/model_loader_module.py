import torch
from transformers import Wav2Vec2Processor, Wav2Vec2ForCTC

class ModelLoaderModule:
    def __init__(self, model_name="kingabzpro/wav2vec2-urdu"):
        self.model_name = model_name
        self.processor = None
        self.model = None
        self.sampling_rate = 16000
        self.model_loaded = False

    def load_model(self):
        try:
            print("Loading Urdu Wav2Vec2 model...")
            self.processor = Wav2Vec2Processor.from_pretrained(self.model_name)
            self.model = Wav2Vec2ForCTC.from_pretrained(self.model_name)
            self.model.eval()
            torch.set_grad_enabled(False)
            self.model_loaded = True
            print("Model loaded successfully.")
            return True
        except Exception as e:
            print("Error loading model:", str(e))
            return False

    def get_model(self):
        return self.model

    def get_processor(self):
        return self.processor

    def get_sampling_rate(self):
        return self.sampling_rate