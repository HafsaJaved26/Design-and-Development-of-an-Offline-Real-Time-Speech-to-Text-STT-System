import os
import speech_recognition as sr
from model_loader_module import ModelLoaderModule
from transliteration_module import UrduToRomanTransliterator
from inference_module import SpeechToTextEngine

# Load model
loader = ModelLoaderModule()
loader.load_model()
transliterator = UrduToRomanTransliterator()
engine = SpeechToTextEngine(loader, transliterator)

# --- USER CHOICE ---
choice = input("Choose input method (file/mic): ").strip().lower()

if choice == "file":
    file_path = input("Enter audio file path: ").strip()
    result = engine.transcribe(file_path, output_format="both")
elif choice == "mic":
    recognizer = sr.Recognizer()
    with sr.Microphone() as source:
        print("Speak now...")
        audio_data = recognizer.record(source, duration=10)  # 10 sec recording
        temp_file = "mic_temp.wav"
        with open(temp_file, "wb") as f:
            f.write(audio_data.get_wav_data())
        result = engine.transcribe(temp_file, output_format="both")
        os.remove(temp_file)

else:
    print("Invalid choice")
    result = None

# --- PRINT RESULTS ---
if result:
    print("\n--- TRANSCRIPTION RESULTS ---")
    print("Urdu Script Output:", result["urdu"])
    print("Roman Urdu Output:", result["roman"])
else:
    print("Transcription failed.")