class UrduToRomanTransliterator:
    def __init__(self):
        self.mapping = {
            "ا": "a", "آ": "aa", "ب": "b", "پ": "p",
            "ت": "t", "ٹ": "t", "ث": "s", "ج": "j",
            "چ": "ch", "ح": "h", "خ": "kh", "د": "d",
            "ڈ": "d", "ذ": "z", "ر": "r", "ڑ": "r",
            "ز": "z", "ژ": "zh", "س": "s", "ش": "sh",
            "ص": "s", "ض": "z", "ط": "t", "ظ": "z",
            "ع": "a", "غ": "gh", "ف": "f", "ق": "q",
            "ک": "k", "گ": "g", "ل": "l", "م": "m",
            "ن": "n", "و": "w", "ہ": "h", "ھ": "h",
            "ی": "y", "ے": "e", "ء": ""
        }

    def convert(self, urdu_text):
        roman_text = ""
        for char in urdu_text:
            roman_text += self.mapping.get(char, char)
        return roman_text