class PartialResultManager:

    def __init__(self):
        # Stores latest partial text from streaming module
        self.current_partial = ""

        # Stores last partial sent to display
        self.last_partial = ""

        # Statistics counters
        self.update_count = 0
        self.clear_count = 0


    def update_partial(self, partial_text):
        """
        Called by the StreamingRecognitionModule whenever
        new partial text is generated.
        """

        self.current_partial = partial_text

        # Check if the new text is different
        if self.current_partial != self.last_partial:
            self.last_partial = self.current_partial
            self.update_count += 1
            return True

        return False


    def get_current_partial(self):
        """Return the latest partial text."""
        return self.current_partial


    def clear_for_final(self):
        """
        Called when a final sentence is detected.
        Clears partial text.
        """

        self.current_partial = ""
        self.last_partial = ""
        self.clear_count += 1


    def get_callback_for_member5(self):
        """
        Returns update_partial function
        so streaming module can call it.
        """
        return self.update_partial


    def get_clear_function(self):
        """
        Returns clear_for_final function
        so final handler can clear partial display.
        """
        return self.clear_for_final


    def get_statistics(self):
        """Return statistics about updates and clears."""
        return {
            "updates": self.update_count,
            "clears": self.clear_count
        }