# test_with_real_audio.py
import numpy as np
from model_loader_module import ModelLoaderModule
from audio_queue_manager_module import AudioQueueManagerModule
from streaming_recognition_module import StreamingRecognitionModule
import time
import threading
from partial_result_manager import PartialResultManager

def partial_cb(text):
    updated = partial_manager.update_partial(text)

    if updated:
        print("📝 PARTIAL:", partial_manager.get_current_partial())

def final_cb(text):
    print("✅ FINAL:", text)
    partial_manager.clear_for_final()

# Load model
loader = ModelLoaderModule()
loader.load_model()
recognizer = loader.get_recognizer()
partial_manager = PartialResultManager()

# Setup queue and streaming
queue = AudioQueueManagerModule()
streaming = StreamingRecognitionModule()
streaming.set_recognizer(recognizer)
streaming.set_queue_manager(queue)
streaming.register_partial_callback(partial_cb)
streaming.register_final_callback(final_cb)


# Start processing
thread = threading.Thread(target=streaming.start_processing)
thread.start()

# Add some test audio (you can replace with real microphone later)
print("Adding test audio...")
for i in range(40):  # 10 seconds of audio
    # Generate a simple sine wave (440 Hz)
    t = np.arange(4000) / 16000
    audio = (np.sin(2 * np.pi * 440 * t) * 32767).astype(np.int16)
    queue.add_to_queue(audio.tobytes())
    time.sleep(0.05)

time.sleep(5)
streaming.stop_processing()
thread.join()

print(f"Stats: {streaming.get_statistics()}")