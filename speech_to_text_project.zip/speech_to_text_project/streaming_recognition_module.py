# streaming_recognition_module.py - UPDATED WITH PARTIAL RESULTS

import time
import numpy as np

class StreamingRecognitionModule:
    def __init__(self):
        self.recognizer = None
        self.queue_manager = None
        self.partial_callback = None
        self.final_callback = None
        self.is_processing = False
        self.chunks_processed = 0
        self.partial_count = 0
        self.final_count = 0
        self.audio_buffer = []
        self.buffer_duration = 2  # 2 seconds buffer
        self.last_partial = ""     # Track last partial for duplicate prevention
        
    def set_recognizer(self, recognizer_object):
        self.recognizer = recognizer_object
        print("✓ Recognizer set")
        
    def set_queue_manager(self, queue_object):
        self.queue_manager = queue_object
        print("✓ Queue manager set")
        
    def register_partial_callback(self, callback_function):
        self.partial_callback = callback_function
        print("✓ Partial callback registered")
        
    def register_final_callback(self, callback_function):
        self.final_callback = callback_function
        print("✓ Final callback registered")
        
    def transcribe_with_whisper(self, audio_array):
        """Actual Whisper transcription"""
        try:
            result = self.recognizer(
                audio_array,
                generate_kwargs={"language": "urdu"}
            )
            return result['text']
        except Exception as e:
            print(f"❌ Transcription error: {e}")
            return ""
        
    def start_processing(self):
        self.is_processing = True
        print("🔄 Processing started with Whisper...")
        
        while self.is_processing:
            audio_chunk = self.queue_manager.get_from_queue()
            
            if audio_chunk:
                self.chunks_processed += 1
                
                # Bytes to numpy array
                if isinstance(audio_chunk, bytes):
                    audio_array = np.frombuffer(audio_chunk, dtype=np.int16).astype(np.float32) / 32768.0
                    self.audio_buffer.append(audio_array)
                
                # Check if buffer has enough audio (2 seconds)
                total_samples = sum(len(buf) for buf in self.audio_buffer)
                if total_samples >= 32000:  # 16000 Hz * 2 sec
                    # Concatenate buffer
                    full_audio = np.concatenate(self.audio_buffer)
                    
                    # Transcribe
                    text = self.transcribe_with_whisper(full_audio)
                    
                    if text:
                        # Send as FINAL result
                        if self.final_callback:
                            self.final_callback(text)
                            self.final_count += 1
                            print(f"✅ FINAL: {text[:50]}...")
                        
                        # Also send partial (last few words)
                        words = text.split()
                        if len(words) > 3:
                            partial = ' '.join(words[-3:])
                            if partial != self.last_partial and self.partial_callback:
                                self.partial_callback(partial)
                                self.partial_count += 1
                                self.last_partial = partial
                                print(f"📝 PARTIAL: {partial}...")
                    
                    # Reset buffer (keep last 1 second for continuity)
                    self.audio_buffer = [full_audio[-16000:]] if len(full_audio) > 16000 else []
                    
            else:
                time.sleep(0.01)
                
    def stop_processing(self):
        self.is_processing = False
        print("🛑 Processing stopped")
        
        # Process remaining audio in buffer
        if self.audio_buffer and self.final_callback:
            full_audio = np.concatenate(self.audio_buffer)
            text = self.transcribe_with_whisper(full_audio)
            if text:
                self.final_callback(text)
                self.final_count += 1
                print(f"✅ FINAL (final): {text[:50]}...")
        return ""
    
    def get_statistics(self):
        return {
            'chunks_processed': self.chunks_processed,
            'partial_count': self.partial_count,
            'final_count': self.final_count
        }