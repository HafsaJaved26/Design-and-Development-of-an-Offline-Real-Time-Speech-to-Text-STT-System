import queue

class AudioQueueManagerModule:
    def __init__(self, max_size=200):
        # Initializing the thread-safe queue
        self.audio_queue = queue.Queue(maxsize=max_size)
        self.max_size = max_size
        
        # Statistics Counters
        self.total_received = 0        # Chunks added by Member 3
        self.total_sent = 0            # Chunks taken by Member 5
        self.queue_full_count = 0      # Failed attempts to add (Queue Full)
        self.queue_empty_count = 0     # Failed attempts to get (Queue Empty)
        self.dropped_chunks = 0        # Total lost chunks

    def add_to_queue(self, audio_chunk):
        """Called by Member 3 to add audio data."""
        try:
            # block=False means it won't wait if queue is full
            self.audio_queue.put_nowait(audio_chunk)
            self.total_received += 1
            return True
        except queue.Full:
            self.queue_full_count += 1
            self.dropped_chunks += 1
            return False

    def get_from_queue(self):
        """Called by Member 5 to retrieve audio data."""
        try:
            chunk = self.audio_queue.get_nowait()
            self.total_sent += 1
            return chunk
        except queue.Empty:
            self.queue_empty_count += 1
            return None

    def get_queue_size(self):
        """Returns the current number of items in the queue."""
        return self.audio_queue.qsize()

    def is_queue_full(self):
        """Checks if the queue has reached its maximum capacity."""
        return self.audio_queue.full()

    def is_queue_empty(self):
        """Checks if the queue is currently empty."""
        return self.audio_queue.empty()

    def get_statistics(self):
        """Returns a summary of the queue activity."""
        current_size = self.get_queue_size()
        # Logic for utilization percentage
        utilization = (current_size / self.max_size) * 100
        
        return {
            'total_received': self.total_received,
            'total_sent': self.total_sent,
            'queue_full_count': self.queue_full_count,
            'queue_empty_count': self.queue_empty_count,
            'dropped_chunks': self.dropped_chunks,
            'current_size': current_size,
            'max_size': self.max_size,
            'utilization_percentage': round(utilization, 2)
        }

    def clear_queue(self):
        """Clears the queue and resets all counters for a new session."""
        while not self.audio_queue.empty():
            try:
                self.audio_queue.get_nowait()
            except queue.Empty:
                break
        
        # Resetting counters
        self.total_received = 0
        self.total_sent = 0
        self.queue_full_count = 0
        self.queue_empty_count = 0
        self.dropped_chunks = 0
        print("Queue cleared and statistics reset.")