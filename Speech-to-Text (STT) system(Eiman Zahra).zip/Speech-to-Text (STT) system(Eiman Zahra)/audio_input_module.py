"""
Audio Input Module
Member 3: Eiman Zahra Awan
Captures audio from microphone continuously and sends chunks to Member 4's queue.
"""

import pyaudio


class AudioInputModule:
    # Audio settings as specified in the PDF
    AUDIO_FORMAT = pyaudio.paInt16   # 16-bit PCM
    CHANNELS = 1                      # Mono
    SAMPLING_RATE = 16000             # 16000 Hz (must match Member 2's model)
    FRAME_BUFFER_SIZE = 4000          # 4000 samples per frame

    def __init__(self):
        self.queue_manager = None      # Will store reference to Member 4's queue
        self.chunk_count = 0           # Counter for number of audio chunks captured
        self.byte_count = 0            # Counter for total bytes of audio captured
        self.is_capturing = False      # Flag indicating if microphone is active

        # Internal PyAudio objects
        self._pyaudio_instance = None
        self._stream = None

    # ------------------------------------------------------------------ #
    #  Connection to Member 4                                              #
    # ------------------------------------------------------------------ #

    def set_queue_manager(self, queue_object):
        """Receive Member 4's queue object from Member 9 and store it."""
        self.queue_manager = queue_object

    # ------------------------------------------------------------------ #
    #  Microphone initialisation                                           #
    # ------------------------------------------------------------------ #

    def initialize_microphone(self):
        """
        Create a PyAudio instance, list available input devices,
        and return True if at least one microphone is found.
        """
        try:
            self._pyaudio_instance = pyaudio.PyAudio()
            device_count = self._pyaudio_instance.get_device_count()

            print("Available audio input devices:")
            input_devices_found = 0
            for i in range(device_count):
                info = self._pyaudio_instance.get_device_info_by_index(i)
                if info.get('maxInputChannels', 0) > 0:
                    print(f"  [{i}] {info['name']} "
                          f"(max inputs: {info['maxInputChannels']})")
                    input_devices_found += 1

            if input_devices_found == 0:
                print("No microphone found. Please connect a microphone.")
                return False

            print(f"Found {input_devices_found} input device(s).")
            return True

        except Exception as e:
            print(f"Error initialising microphone: {e}")
            return False

    # ------------------------------------------------------------------ #
    #  Callback – runs automatically whenever the mic has audio           #
    # ------------------------------------------------------------------ #

    def audio_callback(self, in_data, frame_count, time_info, status):
        """
        Called automatically by PyAudio when a new audio chunk is ready.
        Do NOT call this function manually.
        """
        self.chunk_count += 1
        self.byte_count += len(in_data)

        if self.queue_manager is not None:
            self.queue_manager.add_to_queue(in_data)

        return (None, pyaudio.paContinue)

    # ------------------------------------------------------------------ #
    #  Start / Stop capture                                                #
    # ------------------------------------------------------------------ #

    def start_capture(self):
        """
        Check microphone availability, open a stream with the callback,
        start streaming, and return True on success.
        """
        try:
            if not self.initialize_microphone():
                return False

            self._stream = self._pyaudio_instance.open(
                format=self.AUDIO_FORMAT,
                channels=self.CHANNELS,
                rate=self.SAMPLING_RATE,
                input=True,
                frames_per_buffer=self.FRAME_BUFFER_SIZE,
                stream_callback=self.audio_callback
            )

            self._stream.start_stream()
            self.is_capturing = True
            print("Microphone capture started successfully.")
            return True

        except OSError as e:
            error_msg = str(e).lower()
            if "no default input device" in error_msg or "invalid device" in error_msg:
                print("No microphone found. Please connect a microphone.")
            elif "permission" in error_msg or "access" in error_msg:
                print("Microphone permission denied. Please check your system settings.")
            elif "busy" in error_msg or "in use" in error_msg:
                print("Microphone is busy. Close other applications using the microphone.")
            else:
                print(f"Error starting capture: {e}")
            return False

        except Exception as e:
            print(f"Unexpected error starting capture: {e}")
            return False

    def stop_capture(self):
        """
        Stop and close the stream, terminate PyAudio,
        and return capture statistics.
        """
        try:
            if self._stream is not None:
                self._stream.stop_stream()
                self._stream.close()
                self._stream = None

            if self._pyaudio_instance is not None:
                self._pyaudio_instance.terminate()
                self._pyaudio_instance = None

            self.is_capturing = False
            print("Microphone capture stopped.")

        except Exception as e:
            print(f"Error stopping capture: {e}")
            self.is_capturing = False

        return {
            'chunk_count': self.chunk_count,
            'byte_count': self.byte_count
        }

    # ------------------------------------------------------------------ #
    #  Statistics                                                          #
    # ------------------------------------------------------------------ #

    def get_statistics(self):
        """Return current chunk_count and byte_count."""
        return {
            'chunk_count': self.chunk_count,
            'byte_count': self.byte_count
        }
