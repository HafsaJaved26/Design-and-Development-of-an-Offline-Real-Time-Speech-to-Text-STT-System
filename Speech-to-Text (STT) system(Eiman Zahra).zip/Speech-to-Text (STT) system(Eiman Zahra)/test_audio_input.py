"""
Test script for AudioInputModule (Member 3 – Eiman Zahra Awan)

Run this file directly:   python test_audio_input.py

What it tests
─────────────
1. Module imports correctly.
2. Microphone is detected.
3. Audio chunks are captured and counted for 3 seconds.
4. The mock queue receives the chunks (simulates Member 4's queue).
5. stop_capture() returns correct statistics.
"""

import time
from audio_input_module import AudioInputModule


# ------------------------------------------------------------------ #
#  Minimal mock of Member 4's AudioQueueManagerModule                 #
# ------------------------------------------------------------------ #
class MockQueueManager:
    def __init__(self):
        self.received = []

    def add_to_queue(self, audio_chunk):
        self.received.append(len(audio_chunk))   # store chunk sizes, not raw data
        return True

    def get_queue_size(self):
        return len(self.received)


# ------------------------------------------------------------------ #
#  Tests                                                              #
# ------------------------------------------------------------------ #
def test_import():
    print("TEST 1 – Import ................", end=" ")
    from audio_input_module import AudioInputModule
    print("PASSED")


def test_microphone_detection():
    print("TEST 2 – Microphone detection ..", end=" ")
    module = AudioInputModule()
    result = module.initialize_microphone()
    if result:
        print("PASSED (microphone found)")
    else:
        print("FAILED / WARNING – no microphone detected")
    return result


def test_capture_with_mock_queue():
    print("TEST 3 – Capture (3 seconds) ...")
    module = AudioInputModule()
    mock_queue = MockQueueManager()
    module.set_queue_manager(mock_queue)

    started = module.start_capture()
    if not started:
        print("         SKIPPED – could not open microphone stream")
        return

    print("         Recording for 3 seconds – please speak into the mic …")
    time.sleep(3)

    stats = module.stop_capture()

    print(f"         Chunks captured : {stats['chunk_count']}")
    print(f"         Bytes captured  : {stats['byte_count']}")
    print(f"         Queue received  : {mock_queue.get_queue_size()} chunks")

    if stats['chunk_count'] > 0:
        print("         PASSED")
    else:
        print("         FAILED – no chunks captured")


def test_statistics():
    print("TEST 4 – get_statistics() ......")
    module = AudioInputModule()
    stats = module.get_statistics()
    assert 'chunk_count' in stats, "chunk_count missing"
    assert 'byte_count' in stats,  "byte_count missing"
    print("         PASSED")


def test_stop_without_start():
    print("TEST 5 – stop_capture() without start ..", end=" ")
    module = AudioInputModule()
    stats = module.stop_capture()   # should not raise
    assert stats['chunk_count'] == 0
    assert stats['byte_count']  == 0
    print("PASSED")


# ------------------------------------------------------------------ #
#  Entry point                                                        #
# ------------------------------------------------------------------ #
if __name__ == "__main__":
    print("=" * 50)
    print("AudioInputModule – Test Suite")
    print("=" * 50)

    test_import()
    mic_available = test_microphone_detection()

    if mic_available:
        test_capture_with_mock_queue()
    else:
        print("TEST 3 – SKIPPED (no microphone)")

    test_statistics()
    test_stop_without_start()

    print("=" * 50)
    print("All tests completed.")
    print("=" * 50)
