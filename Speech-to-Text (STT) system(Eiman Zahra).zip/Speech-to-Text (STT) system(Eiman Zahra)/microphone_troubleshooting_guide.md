# Microphone Troubleshooting Guide
### Member 3 – Audio Input Module

---

## Installation

```bash
pip install pyaudio
```

**Windows (if the above fails):**
```bash
pip install pipwin
pipwin install pyaudio
```

**Linux:**
```bash
sudo apt-get install portaudio19-dev python3-pyaudio
pip install pyaudio
```

**macOS:**
```bash
brew install portaudio
pip install pyaudio
```

---

## Common Errors & Fixes

### "No microphone found. Please connect a microphone."
- **Cause:** No input device detected by the OS.
- **Fix:**
  1. Plug in a USB/3.5 mm microphone.
  2. Check Device Manager (Windows) or Sound settings (Mac/Linux).
  3. Restart the application after connecting the device.

---

### "Microphone permission denied. Please check your system settings."
- **Cause:** The OS is blocking microphone access.
- **Fix (Windows):** Settings → Privacy → Microphone → Allow apps to access.
- **Fix (macOS):** System Preferences → Security & Privacy → Microphone → enable Python.
- **Fix (Linux):** Add your user to the `audio` group: `sudo usermod -aG audio $USER` then log out and back in.

---

### "Microphone is busy. Close other applications using the microphone."
- **Cause:** Another app (browser, video call, recording software) already owns the mic.
- **Fix:**
  1. Close Zoom, Teams, Discord, OBS, browser tabs using mic, etc.
  2. On Windows, check the system tray for apps using the mic (orange dot near clock).
  3. Restart the application.

---

### PyAudio installs but `import pyaudio` fails
- **Cause:** Version mismatch or missing PortAudio DLL (Windows).
- **Fix:** Download the correct `.whl` from https://www.lfd.uci.edu/~gohlke/pythonlibs/#pyaudio and install with `pip install <filename>.whl`.

---

### Audio sounds distorted or recognition is poor
- Make sure the sampling rate is exactly **16000 Hz** (required by Member 2's Vosk model).
- Use a **mono** (1-channel) microphone or set channels to 1.
- Reduce background noise; Vosk works best in quiet environments.
- Keep the frame buffer size at **4000 samples**.

---

## Audio Settings Reference

| Setting          | Value         | Reason                              |
|------------------|---------------|-------------------------------------|
| Format           | 16-bit PCM    | Required by Vosk                    |
| Channels         | 1 (Mono)      | Required by Vosk                    |
| Sampling Rate    | 16 000 Hz     | Must match Member 2's model exactly |
| Frame Buffer     | 4 000 samples | ~250 ms chunks; good for streaming  |

---

## Checking Which Devices Are Available

Run the following quick script to list all input devices:

```python
import pyaudio
p = pyaudio.PyAudio()
for i in range(p.get_device_count()):
    info = p.get_device_info_by_index(i)
    if info['maxInputChannels'] > 0:
        print(i, info['name'])
p.terminate()
```

Pass the correct device index to `PyAudio.open(input_device_index=<index>)` if the default device is wrong.
